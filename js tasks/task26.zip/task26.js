var jsonData = [
  {
    Mainland: ["Asia"],
    Country: ["Japan"],
    City: ["Tokyo"],
  },

  {
    Mainland: ["Asia"],
    Country: ["India"],
    City: ["Ahmedabad"],
  },
  {
    Mainland: ["Asia"],
    Country: ["India"],
    City: ["Surat"],
  },

  {
    Mainland: ["North America"],
    Country: ["Mexico"],
    City: ["Mexico City"],
  },
  {
    Mainland: ["Asia"],
    Country: ["Japan"],
    City: ["Kyoto"],
  },
];

let col1 = [];
let col2_1 = [];
let col2_2 = [];
let col3_1 = [];
let col3_2 = [];
let col3_3 = [];
const td1 = jsonData.map((ele) => {
  return ele.Mainland[0];
});

const newTd1 = td1.filter((ele) => {
  if (col1.includes(ele) == false) {
    col1.push(ele);
  }
});

const td2 = jsonData.filter((ele) => {
  if (ele.Mainland[0] == col1[0]) {
    if (!col2_1.includes(ele.Country[0])) {
      col2_1.push(ele.Country[0]);
    }
  } else {
    col2_2.push(ele.Country[0]);
  }
});
jsonData.filter((ele) => {
  if (ele.Country[0] == col2_1[0]) {
    if (!col3_1.includes(ele.City[0])) {
      col3_1.push(ele.City[0]);
    }
  } else {
    if (ele.Country[0] == col2_1[1]) {
      if (!col3_2.includes(ele.City[0])) {
        col3_2.push(ele.City[0]);
      }
    } else {
      col3_3.push(ele.City[0]);
    }
  }
});
let obj = {
  [col1[0]]: {
    [col2_1[0]]: col3_1,
    [col2_1[1]]: col3_2,
  },
  [col1[1]]: {
    [col2_2]: col3_3,
  },
};
console.log(obj);

//------------------------------------------------------------------------------------------------------------------
