const todoList = document.querySelector("#to-do-box");
const btn = document.querySelector("#btn");

btn.addEventListener("click", function () {
  addList();
  item.value = "";
});
const addList = () => {
  const item = document.querySelector("#item").value;
  const list = document.createElement("li");
  list.innerHTML = `${item}<i class="delete fas fa-times"></i>`;
  if(item.length>0){
    todoList.appendChild(list);
  }

  list.querySelector(".delete").addEventListener("click", function () {
    list.remove();
  });
};
